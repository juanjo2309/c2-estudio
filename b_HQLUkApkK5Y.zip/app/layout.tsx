import type { Metadata, Viewport } from 'next'
import { Plus_Jakarta_Sans } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const plusJakarta = Plus_Jakarta_Sans({ 
  subsets: ["latin"],
  weight: ['300', '400', '500', '600', '700', '800'],
  variable: '--font-jakarta'
});

export const metadata: Metadata = {
  title: 'C2 ESTUDIO | Arquitectura y Diseño Interior',
  description: 'Estudio de arquitectura en Formosa, Argentina. Diseñamos espacios claros, resolviendo lo complejo con precisión. Arquitectura, interiores, remodelaciones y habilitaciones comerciales.',
  keywords: ['arquitectura', 'diseño interior', 'remodelaciones', 'habilitaciones comerciales', 'Formosa', 'Argentina', 'estudio de arquitectura'],
  authors: [{ name: 'C2 ESTUDIO' }],
  openGraph: {
    title: 'C2 ESTUDIO | Arquitectura y Diseño Interior',
    description: 'Diseñamos espacios claros, resolviendo lo complejo con precisión.',
    locale: 'es_AR',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#f5f0e8',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" className={plusJakarta.variable}>
      <body className="font-sans antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
