import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export default function NotFound() {
  return (
    <main className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center px-6">
        <span className="text-8xl font-extrabold text-foreground/20">
          404
        </span>
        <h1 className="text-3xl font-bold text-foreground mt-4 mb-3">
          Proyecto no encontrado
        </h1>
        <p className="text-foreground/70 mb-8 max-w-md mx-auto">
          El proyecto que buscás no existe o fue removido de nuestro portfolio.
        </p>
        <Button asChild className="gap-2">
          <Link href="/#proyectos">
            <ArrowLeft size={16} />
            Ver todos los proyectos
          </Link>
        </Button>
      </div>
    </main>
  )
}
