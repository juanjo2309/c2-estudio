import { notFound } from "next/navigation"
import { ProjectDetail } from "@/components/project-detail"
import type { Metadata } from "next"

const projects = [
  {
    id: "casa-jardin",
    title: "Casa Jardín",
    description: "Vivienda unifamiliar con integración de espacios verdes",
    category: "Arquitectura",
    location: "Formosa, Argentina",
    year: "2024",
    area: "180 m²",
    image: "/images/projects/casa-jardin.jpg",
    content: `
      <p>Casa Jardín nace de la voluntad de integrar el interior con el exterior, creando una vivienda que dialoga constantemente con la naturaleza circundante.</p>
      <p>El proyecto se desarrolla en una planta principal que se abre hacia un jardín central, permitiendo que la luz natural inunde todos los espacios durante el día. Los materiales elegidos —hormigón visto, madera y vidrio— generan una paleta neutra que se complementa con el verde del paisaje.</p>
      <p>La distribución prioriza la fluidez entre ambientes, con espacios sociales amplios y áreas privadas que garantizan el descanso. El resultado es una casa contemporánea, funcional y conectada con su entorno.</p>
    `,
  },
  {
    id: "loft-urbano",
    title: "Loft Urbano",
    description: "Renovación integral de departamento en zona céntrica",
    category: "Remodelaciones",
    location: "Resistencia, Chaco",
    year: "2023",
    area: "95 m²",
    image: "/images/projects/loft-urbano.jpg",
    content: `
      <p>Este proyecto transformó un departamento antiguo en un loft contemporáneo, aprovechando al máximo su altura y ubicación céntrica.</p>
      <p>Se eliminaron divisiones innecesarias para crear un espacio fluido donde cocina, comedor y living se integran naturalmente. El dormitorio se elevó a un entrepiso, liberando área útil en la planta baja.</p>
      <p>Los materiales industriales —hormigón pulido, acero negro y madera natural— definen el carácter del espacio, mientras que grandes ventanales garantizan luz natural durante todo el día.</p>
    `,
  },
  {
    id: "cafe-centro",
    title: "Café del Centro",
    description: "Diseño de local gastronómico con identidad propia",
    category: "Habilitaciones",
    location: "Formosa, Argentina",
    year: "2024",
    area: "65 m²",
    image: "/images/projects/cafe-centro.jpg",
    content: `
      <p>Café del Centro es un espacio gastronómico diseñado para crear una experiencia acogedora y memorable para sus visitantes.</p>
      <p>El diseño combina elementos rústicos con toques contemporáneos: ladrillo visto, mobiliario de madera maciza y una iluminación cálida que invita a quedarse. La barra central funciona como corazón del local, permitiendo la interacción entre baristas y clientes.</p>
      <p>Nos encargamos tanto del diseño interior como de toda la gestión de habilitación comercial, asegurando que el local cumpliera con todas las normativas vigentes.</p>
    `,
  },
  {
    id: "residencia-norte",
    title: "Residencia Norte",
    description: "Casa moderna con diseño contemporáneo y funcional",
    category: "Arquitectura",
    location: "Formosa, Argentina",
    year: "2023",
    area: "240 m²",
    image: "/images/projects/residencia-norte.jpg",
    content: `
      <p>Residencia Norte es una vivienda de dos plantas diseñada para una familia joven que buscaba espacios amplios, luminosos y de bajo mantenimiento.</p>
      <p>La planta baja alberga los espacios sociales: living, comedor y cocina integrados, con grandes aberturas que conectan con la galería y el jardín posterior. En planta alta se ubican las habitaciones, cada una con su baño privado.</p>
      <p>La envolvente combina hormigón, vidrio y parasoles de madera que regulan la incidencia solar, logrando un equilibrio entre estética y eficiencia energética.</p>
    `,
  },
  {
    id: "apartamento-luz",
    title: "Apartamento Luz",
    description: "Interiorismo enfocado en luminosidad natural",
    category: "Interiorismo",
    location: "Corrientes, Argentina",
    year: "2024",
    area: "75 m²",
    image: "/images/projects/apartamento-luz.jpg",
    content: `
      <p>El nombre de este proyecto resume su esencia: maximizar la entrada de luz natural en un departamento que, originalmente, se percibía oscuro y compartimentado.</p>
      <p>Se rediseñó la distribución eliminando tabiques innecesarios y se eligió una paleta de colores claros —blancos, beiges y grises suaves— que amplifica la luminosidad. El mobiliario de líneas simples y materiales naturales completa el ambiente.</p>
      <p>El resultado es un espacio sereno, amplio y luminoso que invita al descanso y la contemplación.</p>
    `,
  },
  {
    id: "oficina-creativa",
    title: "Oficina Creativa",
    description: "Espacio de trabajo diseñado para la productividad",
    category: "Habilitaciones",
    location: "Formosa, Argentina",
    year: "2023",
    area: "120 m²",
    image: "/images/projects/oficina-creativa.jpg",
    content: `
      <p>Oficina Creativa es un espacio de coworking diseñado para profesionales independientes y pequeños equipos que buscan un ambiente inspirador para trabajar.</p>
      <p>El diseño prioriza la flexibilidad: escritorios compartidos, salas de reuniones modulares y espacios de descanso que fomentan la creatividad y el intercambio de ideas.</p>
      <p>La vegetación interior, la iluminación natural y los materiales cálidos crean un ambiente profesional pero acogedor. Gestionamos tanto el diseño como la habilitación comercial del espacio.</p>
    `,
  },
  {
    id: "local-comercial",
    title: "Local Comercial",
    description: "Habilitación y diseño de espacio retail",
    category: "Habilitaciones",
    location: "Formosa, Argentina",
    year: "2024",
    area: "50 m²",
    image: "/images/projects/local-comercial.jpg",
    content: `
      <p>Este local de venta de indumentaria requerí­a un diseño que potenciara la exhibición de productos mientras creaba una experiencia de compra memorable.</p>
      <p>Se diseñó un sistema de exhibición modular que permite reorganizar el espacio según la temporada, combinado con una iluminación estudiada que destaca las prendas.</p>
      <p>La gestión integral incluyó el diseño interior, la documentación técnica y el acompañamiento en todo el proceso de habilitación comercial.</p>
    `,
  },
  {
    id: "casa-patio",
    title: "Casa Patio",
    description: "Arquitectura que dialoga con el exterior",
    category: "Arquitectura",
    location: "Formosa, Argentina",
    year: "2024",
    area: "200 m²",
    image: "/images/projects/casa-patio.jpg",
    content: `
      <p>Casa Patio recupera la tipología tradicional de la vivienda con patio central, reinterpretándola con un lenguaje arquitectónico contemporáneo.</p>
      <p>El patio funciona como el corazón de la casa: todos los ambientes se abren hacia él, generando ventilación cruzada natural y un espacio de encuentro familiar al aire libre protegido de las miradas externas.</p>
      <p>La pérgola de madera filtra la luz del sol, creando un juego de sombras que varía según la hora del día. Es una casa pensada para el clima subtropical, que aprovecha las condiciones ambientales en lugar de combatirlas.</p>
    `,
  },
]

type Params = Promise<{ id: string }>

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const resolvedParams = await params
  const project = projects.find((p) => p.id === resolvedParams.id)
  
  if (!project) {
    return {
      title: "Proyecto no encontrado | C2 ESTUDIO",
    }
  }

  return {
    title: `${project.title} | C2 ESTUDIO`,
    description: project.description,
  }
}

export default async function ProjectPage({ params }: { params: Params }) {
  const resolvedParams = await params
  const project = projects.find((p) => p.id === resolvedParams.id)

  if (!project) {
    notFound()
  }

  return <ProjectDetail project={project} />
}
