"use client"

import { useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"
import { ArrowLeft, MapPin, Calendar, Ruler } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Project {
  id: string
  title: string
  description: string
  category: string
  location: string
  year: string
  area: string
  image: string
  content: string
}

interface ProjectDetailProps {
  project: Project
}

export function ProjectDetail({ project }: ProjectDetailProps) {
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const content = contentRef.current
    if (content) {
      content.style.opacity = "0"
      content.style.transform = "translateY(30px)"
      
      setTimeout(() => {
        content.style.transition = "all 1s cubic-bezier(0.16, 1, 0.3, 1)"
        content.style.opacity = "1"
        content.style.transform = "translateY(0)"
      }, 100)
    }
  }, [])

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-b border-border">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <Link href="/" className="text-xl font-bold tracking-tight text-foreground">
            C2 ESTUDIO
          </Link>
          <Button asChild variant="ghost" size="sm" className="gap-2">
            <Link href="/#proyectos">
              <ArrowLeft size={16} />
              Volver a proyectos
            </Link>
          </Button>
        </div>
      </header>

      <div ref={contentRef} className="pt-24">
        {/* Hero Image */}
        <div className="relative h-[50vh] md:h-[70vh]">
          <Image
            src={project.image}
            alt={project.title}
            fill
            className="object-cover"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
        </div>

        {/* Content */}
        <div className="container mx-auto px-6 py-12 md:py-20">
          <div className="max-w-4xl mx-auto">
            {/* Category */}
            <span className="text-sm tracking-widest uppercase text-accent mb-4 block">
              {project.category}
            </span>

            {/* Title */}
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 text-balance">
              {project.title}
            </h1>

            {/* Description */}
            <p className="text-xl text-foreground/80 mb-10 leading-relaxed">
              {project.description}
            </p>

            {/* Meta Info */}
            <div className="flex flex-wrap gap-6 pb-10 mb-10 border-b border-border">
              <div className="flex items-center gap-2 text-foreground/70">
                <MapPin size={18} className="text-accent" />
                <span>{project.location}</span>
              </div>
              <div className="flex items-center gap-2 text-foreground/70">
                <Calendar size={18} className="text-accent" />
                <span>{project.year}</span>
              </div>
              <div className="flex items-center gap-2 text-foreground/70">
                <Ruler size={18} className="text-accent" />
                <span>{project.area}</span>
              </div>
            </div>

            {/* Content */}
            <div 
              className="prose prose-lg max-w-none text-foreground/80 leading-relaxed [&_p]:mb-6"
              dangerouslySetInnerHTML={{ __html: project.content }}
            />

            {/* CTA */}
            <div className="mt-16 p-8 bg-secondary rounded-lg text-center">
              <h3 className="text-2xl font-semibold text-foreground mb-3">
                ¿Tenés un proyecto en mente?
              </h3>
              <p className="text-foreground/70 mb-6">
                Nos encantaría conocer tu idea y ayudarte a hacerla realidad.
              </p>
              <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/#contacto">Contactanos</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
