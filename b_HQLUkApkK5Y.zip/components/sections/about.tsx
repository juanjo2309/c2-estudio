"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"

export function AboutSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="nosotros" className="py-24 md:py-32 bg-secondary">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Image */}
          <div
            className="relative"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? "translateX(0)" : "translateX(-30px)",
              transition: "all 0.8s cubic-bezier(0.16, 1, 0.3, 1)",
            }}
          >
            <div className="relative aspect-[4/5] overflow-hidden rounded-lg">
              <Image
                src="/images/projects/apartamento-luz.jpg"
                alt="C2 Estudio - Diseño interior"
                fill
                className="object-cover"
              />
            </div>
            {/* Decorative element */}
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-accent/10 rounded-lg -z-10" />
          </div>

          {/* Content */}
          <div
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? "translateX(0)" : "translateX(30px)",
              transition: "all 0.8s cubic-bezier(0.16, 1, 0.3, 1) 200ms",
            }}
          >
            <span className="text-sm tracking-widest uppercase text-muted-foreground mb-4 block">
              Sobre Nosotros
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground/85 mb-8">
              Dos arquitectos,
              <br />
              una visión
            </h2>
            
            <div className="space-y-6 text-foreground/80 leading-relaxed">
              <p>
                En C2 ESTUDIO creemos que cada espacio cuenta una historia. Somos dos arquitectos que combinamos creatividad y precisión técnica para transformar ideas en realidades construidas.
              </p>
              <p>
                Nos especializamos en proyectos donde el diseño personalizado, la funcionalidad y la claridad estética convergen. Trabajamos de cerca con cada cliente, entendiendo sus necesidades y traduciendo sus sueños en espacios que mejoran su calidad de vida.
              </p>
              <p>
                Desde Formosa, proyectamos y ejecutamos trabajos en toda la región, adaptándonos a las particularidades de cada lugar y cada persona.
              </p>
            </div>

            <div className="mt-10 pt-10 border-t border-border">
              <div className="grid grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl md:text-4xl font-bold text-foreground mb-1">
                    50+
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Proyectos
                  </div>
                </div>
                <div>
                  <div className="text-3xl md:text-4xl font-bold text-foreground mb-1">
                    8
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Años
                  </div>
                </div>
                <div>
                  <div className="text-3xl md:text-4xl font-bold text-foreground mb-1">
                    100%
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Compromiso
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
