"use client"

import { useEffect, useRef } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowDown } from "lucide-react"

export function HeroSection() {
  const contentRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const content = contentRef.current
    if (content) {
      content.style.opacity = "0"
      content.style.transform = "translateY(30px)"
      
      setTimeout(() => {
        content.style.transition = "all 1s cubic-bezier(0.16, 1, 0.3, 1)"
        content.style.opacity = "1"
        content.style.transform = "translateY(0)"
      }, 300)
    }
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero.jpg"
          alt="Diseño arquitectónico moderno"
          fill
          className="object-cover"
          priority
          quality={90}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/60" />
      </div>

      {/* Content */}
      <div ref={contentRef} className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-7xl lg:text-8xl font-extrabold text-white/90 mb-6 tracking-tight text-balance">
          C2 ESTUDIO
        </h1>
        <p className="text-lg md:text-xl lg:text-2xl text-white/90 mb-4 font-light leading-relaxed text-balance">
          Diseñamos espacios claros, resolviendo lo complejo con precisión
        </p>
        <p className="text-sm md:text-base text-white/70 mb-10 tracking-widest uppercase">
          Arquitectura, interiores y gestión de obra
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            asChild
            size="lg"
            className="bg-white text-foreground hover:bg-white/90 px-8 py-6 text-sm tracking-wide"
          >
            <a href="#proyectos">Ver proyectos</a>
          </Button>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="border-white text-white hover:bg-white/10 px-8 py-6 text-sm tracking-wide bg-transparent"
          >
            <a href="#contacto">Contactar</a>
          </Button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <a href="#confianza" className="text-white/60 hover:text-white/80 transition-colors">
          <ArrowDown size={24} />
        </a>
      </div>
    </section>
  )
}
