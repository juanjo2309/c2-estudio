"use client"

import { useEffect, useRef, useState } from "react"
import { Lightbulb, FileSearch, PenTool, HardHat } from "lucide-react"

const steps = [
  {
    icon: Lightbulb,
    number: "01",
    title: "Idea",
    description:
      "Escuchamos tu idea, necesidades y sueños. Analizamos el terreno o espacio existente y definimos juntos los objetivos del proyecto.",
  },
  {
    icon: FileSearch,
    number: "02",
    title: "Propuesta",
    description:
      "Desarrollamos un anteproyecto con bocetos, renders y estimación de costos. Te presentamos opciones para que elijas la que mejor se adapte a vos.",
  },
  {
    icon: PenTool,
    number: "03",
    title: "Desarrollo",
    description:
      "Elaboramos toda la documentación técnica: planos ejecutivos, detalles constructivos y especificaciones de materiales.",
  },
  {
    icon: HardHat,
    number: "04",
    title: "Ejecución",
    description:
      "Coordinamos y supervisamos la obra, asegurando que cada detalle se ejecute según lo planificado, en tiempo y forma.",
  },
]

export function ProcessSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-24 md:py-32 bg-primary text-primary-foreground">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        >
          <span className="text-sm tracking-widest uppercase text-primary-foreground/70 mb-4 block">
            Cómo trabajamos
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-primary-foreground/85 mb-6">
            Nuestro Proceso
          </h2>
          <p className="text-primary-foreground/80 max-w-2xl mx-auto text-balance">
            Un camino claro y ordenado, donde siempre vas a saber en qué etapa estamos y qué viene después.
          </p>
        </div>

        {/* Steps */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div
              key={step.number}
              className="relative"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? "translateY(0)" : "translateY(30px)",
                transition: `all 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${index * 150}ms`,
              }}
            >
              {/* Connector Line */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-8 left-[60%] w-[80%] h-px bg-primary-foreground/20" />
              )}
              
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-4">
                  <div className="w-16 h-16 rounded-full bg-primary-foreground/10 flex items-center justify-center">
                    <step.icon size={28} className="text-primary-foreground" />
                  </div>
                  <span className="text-4xl font-light text-primary-foreground/30">
                    {step.number}
                  </span>
                </div>
                <h3 className="text-xl font-bold mb-3">
                  {step.title}
                </h3>
                <p className="text-primary-foreground/80 text-sm leading-relaxed">
                  {step.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
