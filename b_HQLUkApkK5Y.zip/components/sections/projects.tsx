"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { ChevronLeft, ChevronRight } from "lucide-react"

const categories = [
  { id: "all", label: "Todos" },
  { id: "arquitectura", label: "Arquitectura" },
  { id: "interiorismo", label: "Interiorismo" },
  { id: "remodelaciones", label: "Remodelaciones" },
  { id: "habilitaciones", label: "Habilitaciones" },
]

const projects = [
  {
    id: "casa-jardin",
    title: "Casa Jardín",
    description: "Vivienda unifamiliar con integración de espacios verdes",
    category: "arquitectura",
    image: "/images/projects/casa-jardin.jpg",
  },
  {
    id: "loft-urbano",
    title: "Loft Urbano",
    description: "Renovación integral de departamento en zona céntrica",
    category: "remodelaciones",
    image: "/images/projects/loft-urbano.jpg",
  },
  {
    id: "cafe-centro",
    title: "Café del Centro",
    description: "Diseño de local gastronómico con identidad propia",
    category: "habilitaciones",
    image: "/images/projects/cafe-centro.jpg",
  },
  {
    id: "residencia-norte",
    title: "Residencia Norte",
    description: "Casa moderna con diseño contemporáneo y funcional",
    category: "arquitectura",
    image: "/images/projects/residencia-norte.jpg",
  },
  {
    id: "apartamento-luz",
    title: "Apartamento Luz",
    description: "Interiorismo enfocado en luminosidad natural",
    category: "interiorismo",
    image: "/images/projects/apartamento-luz.jpg",
  },
  {
    id: "oficina-creativa",
    title: "Oficina Creativa",
    description: "Espacio de trabajo diseñado para la productividad",
    category: "habilitaciones",
    image: "/images/projects/oficina-creativa.jpg",
  },
  {
    id: "local-comercial",
    title: "Local Comercial",
    description: "Habilitación y diseño de espacio retail",
    category: "habilitaciones",
    image: "/images/projects/local-comercial.jpg",
  },
  {
    id: "casa-patio",
    title: "Casa Patio",
    description: "Arquitectura que dialoga con el exterior",
    category: "arquitectura",
    image: "/images/projects/casa-patio.jpg",
  },
]

export function ProjectsSection() {
  const [activeCategory, setActiveCategory] = useState("all")
  const [isVisible, setIsVisible] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [startX, setStartX] = useState(0)
  const [scrollStart, setScrollStart] = useState(0)
  const [hasDragged, setHasDragged] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  const filteredProjects =
    activeCategory === "all"
      ? projects
      : projects.filter((p) => p.category === activeCategory)

  // Reset scroll when category changes
  useEffect(() => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollLeft = 0
    }
  }, [activeCategory])

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  const scroll = (direction: "left" | "right") => {
    if (!scrollContainerRef.current) return
    const container = scrollContainerRef.current
    const cardWidth = container.querySelector("a")?.offsetWidth || 300
    const gap = 24
    const scrollAmount = (cardWidth + gap) * 3
    
    container.scrollBy({
      left: direction === "left" ? -scrollAmount : scrollAmount,
      behavior: "smooth"
    })
  }

  // Mouse events for desktop drag
  const handleMouseDown = (e: React.MouseEvent) => {
    if (!scrollContainerRef.current) return
    setIsDragging(true)
    setHasDragged(false)
    setStartX(e.pageX - scrollContainerRef.current.offsetLeft)
    setScrollStart(scrollContainerRef.current.scrollLeft)
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging || !scrollContainerRef.current) return
    e.preventDefault()
    const x = e.pageX - scrollContainerRef.current.offsetLeft
    const walk = (x - startX) * 1.5
    scrollContainerRef.current.scrollLeft = scrollStart - walk
    if (Math.abs(walk) > 5) {
      setHasDragged(true)
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  const handleMouseLeave = () => {
    setIsDragging(false)
  }

  // Touch events
  const handleTouchStart = (e: React.TouchEvent) => {
    if (!scrollContainerRef.current) return
    setIsDragging(true)
    setHasDragged(false)
    setStartX(e.touches[0].pageX - scrollContainerRef.current.offsetLeft)
    setScrollStart(scrollContainerRef.current.scrollLeft)
  }

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || !scrollContainerRef.current) return
    const x = e.touches[0].pageX - scrollContainerRef.current.offsetLeft
    const walk = (x - startX) * 1.5
    scrollContainerRef.current.scrollLeft = scrollStart - walk
    if (Math.abs(walk) > 5) {
      setHasDragged(true)
    }
  }

  const handleTouchEnd = () => {
    setIsDragging(false)
  }

  // Prevent click if dragged
  const handleLinkClick = (e: React.MouseEvent) => {
    if (hasDragged) {
      e.preventDefault()
    }
  }

  return (
    <section ref={sectionRef} id="proyectos" className="py-24 md:py-32 bg-background overflow-hidden">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div
          className="text-center mb-12"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        >
          <span className="text-sm tracking-widest uppercase text-muted-foreground mb-4 block">
            Portfolio
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground/85">
            Nuestros Proyectos
          </h2>
        </div>

        {/* Category Filter */}
        <div
          className="flex flex-wrap justify-center gap-2 md:gap-4 mb-12"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.16, 1, 0.3, 1) 100ms",
          }}
        >
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={cn(
                "px-4 py-2 text-sm transition-all duration-300 rounded-full",
                activeCategory === cat.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Carousel */}
        <div
          className="relative"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.16, 1, 0.3, 1) 200ms",
          }}
        >
          <div className="flex items-center gap-4">
            {/* Previous Button - Desktop */}
            <button
              onClick={() => scroll("left")}
              className="hidden md:flex flex-shrink-0 w-12 h-12 rounded-full border border-border items-center justify-center transition-all duration-300 hover:bg-primary hover:text-primary-foreground hover:border-primary"
              aria-label="Proyectos anteriores"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            {/* Scrollable Container */}
            <div 
              ref={scrollContainerRef}
              className={cn(
                "flex-1 overflow-x-auto scrollbar-thin scrollbar-thumb-border scrollbar-track-transparent pb-4",
                isDragging ? "cursor-grabbing" : "cursor-grab",
                "scroll-smooth"
              )}
              style={{
                scrollbarWidth: "thin",
                scrollBehavior: isDragging ? "auto" : "smooth",
              }}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseLeave}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
            >
              <div className="flex gap-6" style={{ width: "max-content" }}>
                {filteredProjects.map((project, index) => (
                  <Link
                    key={project.id}
                    href={`/proyectos/${project.id}`}
                    onClick={handleLinkClick}
                    className="group block flex-shrink-0 w-[280px] sm:w-[320px] md:w-[calc((100vw-12rem-6rem)/3)] md:max-w-[380px] select-none"
                    draggable={false}
                    style={{
                      opacity: isVisible ? 1 : 0,
                      transform: isVisible ? "translateY(0)" : "translateY(20px)",
                      transition: `all 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${index * 80}ms`,
                    }}
                  >
                    <div className="relative aspect-[4/5] overflow-hidden rounded-lg mb-4">
                      <Image
                        src={project.image}
                        alt={project.title}
                        fill
                        className="object-cover transition-transform duration-700 group-hover:scale-105 pointer-events-none"
                        draggable={false}
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300 pointer-events-none" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground/90 mb-1 group-hover:text-accent transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {project.description}
                    </p>
                  </Link>
                ))}
              </div>
            </div>

            {/* Next Button - Desktop */}
            <button
              onClick={() => scroll("right")}
              className="hidden md:flex flex-shrink-0 w-12 h-12 rounded-full border border-border items-center justify-center transition-all duration-300 hover:bg-primary hover:text-primary-foreground hover:border-primary"
              aria-label="Siguientes proyectos"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Drag Hint */}
          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground mt-6">
            <ChevronLeft className="w-4 h-4" />
            <span>Deslizá para ver más</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      <style jsx>{`
        /* Custom scrollbar styling */
        div::-webkit-scrollbar {
          height: 6px;
        }
        div::-webkit-scrollbar-track {
          background: transparent;
        }
        div::-webkit-scrollbar-thumb {
          background: hsl(var(--border));
          border-radius: 3px;
        }
        div::-webkit-scrollbar-thumb:hover {
          background: hsl(var(--muted-foreground));
        }
      `}</style>
    </section>
  )
}
