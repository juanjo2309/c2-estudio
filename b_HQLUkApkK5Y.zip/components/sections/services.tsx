"use client"

import { useEffect, useRef, useState } from "react"
import { Home, Sofa, Wrench, FileCheck, FileText } from "lucide-react"

const services = [
  {
    icon: Home,
    title: "Diseño arquitectónico",
    description:
      "Proyectamos viviendas, edificios y espacios comerciales desde cero. Nos encargamos de todo: desde el primer boceto hasta los planos finales para construcción.",
  },
  {
    icon: Sofa,
    title: "Diseño de interiores",
    description:
      "Transformamos espacios existentes en ambientes funcionales y estéticos. Seleccionamos materiales, colores, mobiliario e iluminación para crear el ambiente que buscás.",
  },
  {
    icon: Wrench,
    title: "Remodelaciones",
    description:
      "Renovamos y actualizamos tu espacio, ya sea una casa, departamento o local. Coordinamos todos los trabajos necesarios para lograr el resultado deseado.",
  },
  {
    icon: FileCheck,
    title: "Habilitaciones comerciales",
    description:
      "Gestionamos todos los trámites y documentación necesaria para habilitar tu local o comercio. Nos ocupamos de que todo esté en regla para que puedas abrir sin problemas.",
  },
  {
    icon: FileText,
    title: "Documentación técnica",
    description:
      "Elaboramos planos, memorias técnicas y toda la documentación que necesites para tu proyecto, ya sea para construcción, trámites municipales o presentaciones bancarias.",
  },
]

export function ServicesSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.1 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} id="servicios" className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        >
          <span className="text-sm tracking-widest uppercase text-muted-foreground mb-4 block">
            Lo que hacemos
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-foreground/85 mb-6">
            Nuestros Servicios
          </h2>
          <p className="text-foreground/70 max-w-2xl mx-auto text-balance">
            Ofrecemos soluciones integrales de arquitectura y diseño, adaptadas a las necesidades específicas de cada proyecto.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div
              key={service.title}
              className="group p-8 rounded-lg bg-card border border-border hover:border-accent/30 hover:shadow-lg transition-all duration-500"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? "translateY(0)" : "translateY(30px)",
                transition: `all 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${index * 100}ms`,
              }}
            >
              <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center text-accent mb-6 group-hover:bg-accent group-hover:text-accent-foreground transition-colors duration-300">
                <service.icon size={22} />
              </div>
              <h3 className="text-xl font-semibold text-foreground/90 mb-3">
                {service.title}
              </h3>
              <p className="text-foreground/70 leading-relaxed text-sm">
                {service.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
