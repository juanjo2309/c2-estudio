"use client"

import { useEffect, useRef, useState } from "react"
import { Palette, Eye, Layers } from "lucide-react"

const values = [
  {
    icon: Palette,
    title: "Diseño personalizado",
    description: "Cada proyecto es único y refleja las necesidades y estilo de vida de cada cliente.",
  },
  {
    icon: Eye,
    title: "Claridad en el proceso",
    description: "Comunicación transparente en cada etapa, sin sorpresas ni términos confusos.",
  },
  {
    icon: Layers,
    title: "Gestión integral",
    description: "Acompañamiento completo desde la idea inicial hasta la entrega final.",
  },
]

export function TrustSection() {
  const [isVisible, setIsVisible] = useState(false)
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true)
        }
      },
      { threshold: 0.2 }
    )

    if (sectionRef.current) {
      observer.observe(sectionRef.current)
    }

    return () => observer.disconnect()
  }, [])

  return (
    <section
      ref={sectionRef}
      id="confianza"
      className="py-24 md:py-32 bg-secondary"
    >
      <div className="container mx-auto px-6">
        <div
          className="max-w-3xl mx-auto text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.8s cubic-bezier(0.16, 1, 0.3, 1)",
          }}
        >
          <p className="text-lg md:text-xl text-foreground/80 leading-relaxed text-balance">
            Te acompañamos desde la idea hasta la ejecución, simplificando cada etapa del proceso.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 md:gap-12">
          {values.map((value, index) => (
            <div
              key={value.title}
              className="text-center"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? "translateY(0)" : "translateY(30px)",
                transition: `all 0.8s cubic-bezier(0.16, 1, 0.3, 1) ${index * 150}ms`,
              }}
            >
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-accent/10 text-accent mb-6">
                <value.icon size={24} />
              </div>
              <h3 className="text-xl font-bold mb-3 text-foreground/90">
                {value.title}
              </h3>
              <p className="text-foreground/70 leading-relaxed">
                {value.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
